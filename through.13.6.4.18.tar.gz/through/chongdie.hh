#ifndef chongdie_h
#define chongdie_h

void procchongdie(edgec & edge, string & featval);
void recurprocyx(edgec & edge, string & yxval);
void procyinjin(edgec & edge, string & yinjieval);
void findfinaldesc(edgec & edge, edgec & desce);

#endif
